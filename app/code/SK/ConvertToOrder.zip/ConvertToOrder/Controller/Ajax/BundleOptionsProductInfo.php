<?php
namespace SK\ConvertToOrder\Controller\Ajax;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Exception\NoSuchEntityException;

class BundleOptionsProductInfo extends Action
{
    protected $resultJsonFactory;
    protected $productRepository;

    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        ProductRepository $productRepository
    ) {
        
        $this->resultJsonFactory = $resultJsonFactory;
        $this->productRepository = $productRepository;
        return parent::__construct($context);
    }

    public function execute()
    {
        //echo 'gdfgfd';die;
        
        $resultJson = $this->resultJsonFactory->create();
        $bundleProductId = $this->getRequest()->getParam('bundle_product_id');

        if (!$bundleProductId) {
            return $resultJson->setData(['error' => true, 'message' => 'No bundle product provided']);
        }

        try {
            $product = $this->productRepository->getById($bundleProductId);

            if ($product->getTypeId() !== 'bundle') {
                return $resultJson->setData(['error' => true, 'message' => 'Not a bundle product']);
            }

            $options = [];
            $bundleOptions = $product->getExtensionAttributes()->getBundleProductOptions();

            if ($bundleOptions) {
                foreach ($bundleOptions as $option) {
                    $selections = [];
                    foreach ($option->getProductLinks() as $selection) {
                        $selectionsProduct = $this->productRepository->get($selection->getSku());
                        $selections[] = [
                            'product_id' => $selection->getId(),
                            'sku' => $selection->getSku(),
                            'price' => $selection->getPrice(),
                            'default_qty' => $selection->getQty(),
                            'tdp' => $selectionsProduct->getTdp(),
                            'heatsink_performance' => $selectionsProduct->getHeatsinkPerformance()
                        ];
                    }

                    $options[] = [
                        'option_id' => $option->getOptionId(),
                        'title' => $option->getTitle(),
                        'type' => $option->getType(),
                        'required' => $option->getRequired(),
                        'selections' => $selections,
                    ];
                }
            }

            return $resultJson->setData(['success' => true, 'options' => $options]);

        } catch (NoSuchEntityException $e) {
            return $resultJson->setData(['error' => true, 'message' => 'Product not found']);
        }
    }
}
