define([
    'jquery',
    'mage/url',
], function ($, url) {
    'use strict';

    return function (originalPriceBundle) {
        $.widget('mage.priceBundle', originalPriceBundle, {
            
            _init: function initPriceBundle() {
                this._super();
                this.updateOptionQty();
            },

            /**
             * @private
             */
            _create: function createPriceBundle() {
                this._super();
                //this.updateOptionQty();  
            },
            
            /**
             * Update bundle option qty
             */
            updateOptionQty: function() {

                $('.bundle-option-qty').on('change', function () {
        
                    console.log('Product : ' +$('input[name="product"]').val());

                    var selectionId = $(this).data('selection-id');
                    var optionId = $(this).data('option-id');
                    var newQty = $(this).val();
                    var bundleProductId = $('input[name="product"]').val();
                    console.log(optionId + ' '+newQty);

                    

                    $('select[name="bundle_option[' + optionId + ']"]').trigger('change');
                    
        
                    if(newQty > 0) {

                        $('select[name="bundle_option[' + optionId + ']"]').val(selectionId);
                        
                        $('input[name="bundle_option_qty[' + optionId + ']"]').val(newQty).trigger('change');
                        
                        // Disable all other tier prices except the one related to this option
                        $('.options-' + optionId).removeClass('active', false).addClass('disabled', true); // Disable all
                        
        
                        //$('#option-tier-prices-' + optionId).removeClass('disabled', false); // Enable only related
                        $('.options-'+ optionId + '-' + selectionId).removeClass('disabled', false).addClass('active', true); // Enable only related
                    } else {

                        //$('select[name="bundle_option[' + optionId + ']"]').val(selectionId).trigger('change');
                       // $('input[name="bundle_option_qty[' + optionId + ']"]').val('');
                        // Enable all other tier prices except the one related to this option
                        $('.options-' + optionId).removeClass('active', false).removeClass('disabled', false); // Disable all
                        
                    }


                    $.ajax({
                        url: url.build('configure_bundle/ajax/bundleOptionsProductInfo'),
                        type: 'GET',
                        data: {bundle_product_id: bundleProductId, form_key: window.FORM_KEY},
                        dataType: 'json',
                        success: function (response) {
                            optionDropdown.empty();
                            
                            $.each(response.options, function (key, value) {
                                optionDropdown.append(new Option(value.label, value.value));
                            });
                        },
                        error: function () {
                            console.error('Failed to fetch bundle options. ');
                        }
                    });
                
                    
                    
                });
            }
        });

        return $.mage.priceBundle;
    };
});
