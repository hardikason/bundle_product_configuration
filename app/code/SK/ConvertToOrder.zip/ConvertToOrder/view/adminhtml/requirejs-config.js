var config = {
    deps: [
        "SK_ConvertToOrder/js/dynamic-rows"
    ]
    // config: {
    //     mixins: {
    //         'Magento_Ui/js/dynamic-rows/dynamic-rows': {
    //             'SK_ConvertToOrder/js/dynamic-rows': true
    //         }
    //     }
    // }
};
